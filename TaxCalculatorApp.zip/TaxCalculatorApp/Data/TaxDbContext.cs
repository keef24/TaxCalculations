﻿
using Microsoft.EntityFrameworkCore;
using TaxCalculatorApp.Models;

public class TaxDbContext : DbContext
{
    public TaxDbContext(DbContextOptions<TaxDbContext> options) : base(options) { }

    public DbSet<Tax> Taxes { get; set; }
}
