﻿// TaxController.cs
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using TaxCalculatorApp.Models;

public class TaxController : Controller
{
    private readonly TaxDbContext _dbContext;

    public TaxController(TaxDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public IActionResult Index()
    {
        var taxes = _dbContext.Taxes.ToList();
        return View(taxes);
    }

    public IActionResult Create()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Create(Tax tax)
    {
        if (ModelState.IsValid)
        {
            _dbContext.Taxes.Add(tax);
            _dbContext.SaveChanges();
            return RedirectToAction("Index");
        }
        return View(tax);
    }

    public IActionResult Edit(int id)
    {
        var tax = _dbContext.Taxes.Find(id);
        if (tax == null)
        {
            return NotFound();
        }
        return View(tax);
    }

    [HttpPost]
    public IActionResult Edit(Tax tax)
    {
        if (ModelState.IsValid)
        {
            _dbContext.Taxes.Update(tax);
            _dbContext.SaveChanges();
            return RedirectToAction("Index");
        }
        return View(tax);
    }

    public IActionResult Delete(int id)
    {
        var tax = _dbContext.Taxes.Find(id);
        if (tax == null)
        {
            return NotFound();
        }
        return View(tax);
    }

    [HttpPost]
    public IActionResult DeleteConfirmed(int id)
    {
        var tax = _dbContext.Taxes.Find(id);
        if (tax != null)
        {
            _dbContext.Taxes.Remove(tax);
            _dbContext.SaveChanges();
        }
        return RedirectToAction("Index");
    }
}
