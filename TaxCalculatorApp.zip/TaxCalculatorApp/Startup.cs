﻿
using Microsoft.EntityFrameworkCore;



public void ConfigureServices(IServiceCollection services)
{
    
    services.AddDbContext<TaxDbContext>(options =>
        options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));
    services.AddControllersWithViews();
    
}
