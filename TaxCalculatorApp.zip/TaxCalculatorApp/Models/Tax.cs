﻿namespace TaxCalculatorApp.Models
{
   
        
        public class Tax
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public decimal Amount { get; set; }
        public string TaxCalculationType { get; set; }
        public String PostalCode { get; set; }
        
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }

    }

    }

